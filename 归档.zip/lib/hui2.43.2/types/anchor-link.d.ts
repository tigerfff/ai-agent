import { HuiComponent } from './components';

export declare class HAnchorLink extends HuiComponent {}

// 主题
export type ComponentType = 'success' | 'warning' | 'info' | 'error';
// 尺寸
export type ComponentSize = 'small' | 'large';
// 文本输入框类型
export type ComponentInputType = 'text' | 'textarea';

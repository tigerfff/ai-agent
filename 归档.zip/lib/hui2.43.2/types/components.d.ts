import Vue from 'vue';

export declare class HuiComponent extends Vue {
  static install(vue: typeof Vue): void;
}

import HFeedbackIcon from '../icon/src/feedback-icon.vue';

/* istanbul ignore next */
HFeedbackIcon.install = function(Vue) {
  Vue.component(HFeedbackIcon.name, HFeedbackIcon);
};

export default HFeedbackIcon;

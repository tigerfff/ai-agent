import ElBreadcrumbSubItem from '../breadcrumb/src/breadcrumb-sub-item';

/* istanbul ignore next */
ElBreadcrumbSubItem.install = function(Vue) {
  Vue.component(ElBreadcrumbSubItem.name, ElBreadcrumbSubItem);
};

export default ElBreadcrumbSubItem;

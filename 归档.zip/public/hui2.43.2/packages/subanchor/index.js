import HSubanchor from '../anchor/src/subanchor';

HSubanchor.install = function(Vue) {
  Vue.component(HSubanchor.name, HSubanchor);
};

export default HSubanchor;

import ElCollapseItem from '../collapse/src/collapse-item.vue';

/* istanbul ignore next */
ElCollapseItem.install = function(Vue) {
  Vue.component(ElCollapseItem.name, ElCollapseItem);
};

export default ElCollapseItem;
